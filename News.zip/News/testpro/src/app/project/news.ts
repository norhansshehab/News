export class News {
    constructor(
        public ID : number,
        public Title : string,
        public Description : string,
        public ImageName : string
    ){}
}
